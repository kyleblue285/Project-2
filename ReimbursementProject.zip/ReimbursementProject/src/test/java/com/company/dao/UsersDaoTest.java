package com.company.dao;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.company.Dao.UserDao;
import com.company.project.Users;



public class UsersDaoTest {
	
	private UserDao ud;
	
	@BeforeEach
	public void setup() {
		ud=new UserDao();
	}
	
	@Test
	public Users LoginTest(){
		Users u = ud.Login("employee","pass");
		System.out.println(u);
		return u;
	}
	
//	@Test
//	public void findAllTest() {
//		List<Users> users = ud.findall();
//		assertNotNull(users);
//		assertNotEquals(0, users.size());
//	    System.out.println(users);
//	}
	

}
