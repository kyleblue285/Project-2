package com.company.Dao;

import java.util.List;

import com.company.project.*;;

public class UserDao implements DaoContract<Users, Integer>{

	@Override
	public List<Users> findall() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Users findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(Users t) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(Integer id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Users insert(Users t) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
