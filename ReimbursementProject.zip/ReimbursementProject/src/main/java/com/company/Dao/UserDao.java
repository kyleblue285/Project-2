package com.company.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import com.company.project.*;
import com.example.config.ConnectionUtil;;

public class UserDao implements DaoContract<Users, Integer>{

	@Override
	public List<Users> findall() {
		List<Users> users = new LinkedList<>();
		try(Connection conn = ConnectionUtil.getInstance().getConnection()){
			String sql = "select * from employee";
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				users.add(new Users(rs.getString("username"),rs.getString("password"),rs.getString("firstname"),rs.getString("lastname"),
						rs.getString("email"),rs.getInt("userid"),rs.getBoolean("managestatus")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}

	@Override
	public Users findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(Users t) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(Integer id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Users insert(Users t) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public Users Login(String username, String password) {
		Users u = null;
		try {
			Connection conn = ConnectionUtil.getInstance().getConnection();
			String sql = "select * from employee";
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				if (username.equalsIgnoreCase(rs.getString("username")) 
						&& password.equalsIgnoreCase(rs.getString("password")) )
				{
					u = new Users(rs.getString("username"),rs.getString("password"),rs.getString("firstname"),rs.getString("lastname"),
							rs.getString("email"),rs.getInt("userid"),rs.getBoolean("managestatus"));	
				};	
			}
			conn.close();
			ps.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return u;
	}
	
	public boolean checkManage(String username) {
		boolean u = false;
		Users user = null;
		try {
			Connection conn = ConnectionUtil.getInstance().getConnection();
			String sql = "select * from employee";
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				if (username.equalsIgnoreCase(rs.getString("username")))
				{
					user = new Users(rs.getString("username"),rs.getString("password"),rs.getString("firstname"),rs.getString("lastname"),
							rs.getString("email"),rs.getInt("userid"),rs.getBoolean("managestatus"));
				};	
			}
			conn.close();
			ps.close();
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		u = user.isManagestatus();
		return u;
	}
	

}
