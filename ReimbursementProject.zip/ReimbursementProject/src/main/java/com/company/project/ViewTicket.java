package com.company.project;

public class ViewTicket extends LoginScreen{
	
	

}
