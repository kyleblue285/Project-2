package com.company.service;

import java.util.List;

import com.company.Dao.UserDao;
import com.company.project.Users;

public class UserService {
	
	private UserDao ud;
	
	public UserService() {
		ud = new UserDao();
	}
	
	public List<Users> findAll(){
		return ud.findall();
	}

}
