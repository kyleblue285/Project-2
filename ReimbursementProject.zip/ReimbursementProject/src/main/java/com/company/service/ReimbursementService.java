package com.company.service;

import java.util.List;

import com.company.Dao.ReimbursementDao;
import com.company.project.Reimbursement;

public class ReimbursementService {
	
	private ReimbursementDao rd;
	
	public ReimbursementService() {
		rd = new ReimbursementDao();
	}
	
	public List<Reimbursement> findByUser(String username){
		return rd.findByUser(username);
	}
	
	public List<Reimbursement> findall(){
		return rd.findall();
	}
	
	public void createTicket(String username, String reimType, Double amount, String submitDate, String description) {
		rd.createTicket(username, reimType, amount, submitDate, description);
	}
	
	public List<Reimbursement> checkPending(){
		return rd.checkPending();
	}
	
	public void approveTicket(int id, String resolveDate) {
		rd.approveTicket(id, resolveDate);
	}
	
	public void denyTicket(int id, String resolveDate) {
		rd.denyTicket(id, resolveDate);
	}

}
