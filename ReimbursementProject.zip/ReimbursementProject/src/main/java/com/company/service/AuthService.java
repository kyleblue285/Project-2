package com.company.service;

import com.company.Dao.UserDao;
import com.company.project.Users;

public class AuthService {
	
	private UserDao ud;
	
	public AuthService() {
		ud = new UserDao();
	}
	
	public boolean Login(String username, String password) {
		Users u = ud.Login(username, password);
		return password.equals(u.getPassword());
	}
	
	public boolean checkManage(String username) {
		return ud.checkManage(username);
	}

}
