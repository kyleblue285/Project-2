package com.company.Controller;

import javax.servlet.http.HttpServletRequest;

import com.company.service.AuthService;

public class AuthController {
	
	private AuthService as;

	public AuthController() {
		as = new AuthService();
	}

	public String login(HttpServletRequest req) {
		String username = req.getParameter("user");
		String password = req.getParameter("pass");
		boolean b = as.Login(username, password);
		if(b) {
			new SessionController().CreateSession(req);
			if(as.checkManage(username)) {
				return "/html/loginServlet.html";
			}
			else {
				return "/html/employee.html";
			}	
		} else {
			return "/html/404-page.html";
		}
	}

	
}
