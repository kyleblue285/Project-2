package com.company.Controller;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.company.service.ReimbursementService;
import com.google.gson.Gson;

public class ReimbursementController {
	
	private ReimbursementService rs;
	
	public ReimbursementController() {
		rs = new ReimbursementService();
	}
	
	public String findByUser(HttpServletRequest req, HttpServletResponse res) {
		String json = "";
		String [] stringArray = new String[0];
		try {
			HttpSession session = req.getSession();
			String user = (String) session.getAttribute("user");
			System.out.print(user);
			System.out.println(rs.findByUser(user));
			json = new Gson().toJson(rs.findByUser(user));	
//			Object[] objectArray = rs.findByUser(user).toArray();
//			int length = objectArray.length;
//			stringArray = new String[length];
//			for(int i=0; i<length; i++) {
//				stringArray[i] = (String) objectArray[i];
//			}
			res.setContentType("application/json");
			res.setCharacterEncoding("UTF-8");
			res.getWriter().write(json);
			System.out.println(json);
		} catch(IOException e) {
			e.printStackTrace();
		}
		return json;
	}
	
	public String checkPending(HttpServletRequest req, HttpServletResponse res) {
		String json = "";
		String [] stringArray = new String[0];
		try {
			HttpSession session = req.getSession();
			System.out.println(rs.checkPending());
			json = new Gson().toJson(rs.checkPending());	
//			Object[] objectArray = rs.findByUser(user).toArray();
//			int length = objectArray.length;
//			stringArray = new String[length];
//			for(int i=0; i<length; i++) {
//				stringArray[i] = (String) objectArray[i];
//			}
			res.setContentType("application/json");
			res.setCharacterEncoding("UTF-8");
			res.getWriter().write(json);
			System.out.println(json);
		} catch(IOException e) {
			e.printStackTrace();
		}
		return json;
	}
	
	public String createTicket(HttpServletRequest req) {
		System.out.println("Creating a new ticket");
		HttpSession session = req.getSession();
		String user = req.getParameter("user");
		String pass = req.getParameter("pass");
		String reimType = req.getParameter("reimType");
		if(reimType.equalsIgnoreCase("option1")) {
			reimType = "LODGING";
		}
		else if(reimType.equalsIgnoreCase("option2")) {
			reimType = "TRAVEL";
		}
		else if(reimType.equalsIgnoreCase("option3")) {
			reimType = "FOOD";
		}
		else if(reimType.equalsIgnoreCase("option4")) {
			reimType = "OTHER";
		}
		double amount = Double.valueOf(req.getParameter("amount"));
		String submitDate = req.getParameter("date");
		String description = req.getParameter("description");
		rs.createTicket(user, reimType, amount, submitDate, description);
		return "/html/employee.html";
		
	}
	
	public String approveTicket(HttpServletRequest req) {
		System.out.println("Approving a ticket");
		HttpSession session = req.getSession();
		int id = Integer.valueOf(req.getParameter("reimbID"));
		String resolveDate = req.getParameter("date");
		rs.approveTicket(id, resolveDate);
		return "/html/loginServlet.html";
	}
	
	public String denyTicket(HttpServletRequest req) {
		System.out.println("Denying a ticket");
		HttpSession session = req.getSession();
		int id = Integer.valueOf(req.getParameter("reimbID2"));
		String resolveDate = req.getParameter("date2");
		rs.denyTicket(id, resolveDate);
		return "/html/loginServlet.html";
	}

}
