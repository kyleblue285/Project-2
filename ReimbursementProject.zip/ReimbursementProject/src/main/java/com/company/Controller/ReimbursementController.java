package com.company.Controller;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.company.service.ReimbursementService;
import com.google.gson.Gson;

public class ReimbursementController {
	
	private ReimbursementService rs;
	
	public ReimbursementController() {
		rs = new ReimbursementService();
	}
	
	public String findByUser(HttpServletRequest req, HttpServletResponse res) {
		String json = "";
		String [] stringArray = new String[0];
		try {
			HttpSession session = req.getSession();
			String user = (String) session.getAttribute("user");
			System.out.println(rs.findByUser(user));
			json = new Gson().toJson(rs.findByUser(user));	
//			Object[] objectArray = rs.findByUser(user).toArray();
//			int length = objectArray.length;
//			stringArray = new String[length];
//			for(int i=0; i<length; i++) {
//				stringArray[i] = (String) objectArray[i];
//			}
			res.getWriter().print(json);
			System.out.println(json);
		} catch(IOException e) {
			e.printStackTrace();
		}
		return json;
	}

}
