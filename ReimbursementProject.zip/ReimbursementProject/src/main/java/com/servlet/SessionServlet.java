package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "session", urlPatterns = { "*.sess" })
public class SessionServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession sess = req.getSession();
		resp.getWriter()
				.print("the user is: " + req.getParameter("user")
						+ " and their password is: " + req.getParameter("pass") + " id is: "
						+ sess.getId());
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession sess = req.getSession();
		switch (req.getRequestURI()) {
		case "/ReimbursementProject/login.sess":
			sess.setAttribute("username", req.getParameter("user"));
			sess.setAttribute("pass", req.getParameter("pass"));
			break;
		case "/ReimbursementProject/invalidate.sess":
			sess.invalidate();
		}
	}

}
