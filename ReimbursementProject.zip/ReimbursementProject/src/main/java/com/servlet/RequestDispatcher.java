package com.servlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.company.Controller.AuthController;
import com.company.Controller.UserController;

public class RequestDispatcher {
	
	public static void dataRetriever(HttpServletRequest req, HttpServletResponse res) {
		System.out.println(req.getRequestURI());
		switch (req.getRequestURI()) {
		case "/ReimbursementProject/user.json":
			new UserController().findAllUsers(req, res);
			break;
		}
	}

	public static String retrievePage(HttpServletRequest req) {
		System.out.println(req.getRequestURI());
		
		switch (req.getRequestURI()) {
		case "/ReimbursementProject/html/login.app":
			return new AuthController().login(req);
		case "/ReimbursementProject/anything.app":
			return "/webapp/html/404-page.html";
		default:
			return "/webapp/html/404-page.html";
		}
	}

}
