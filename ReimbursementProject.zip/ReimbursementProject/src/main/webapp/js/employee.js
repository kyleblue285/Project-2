function closeMe(){
      // Find the element
   		x=document.getElementById("formDisplay");
       //Option 1: Change the style attribute directly
   		x.style.display="none";
  
	}

function openMe(){
      // Find the element
   		x=document.getElementById("formDisplay");
      //Option 1: Change the style attribute directly
   		 x.style.display="block";
 
	}
function closeTable(){
      // Find the element
   		x=document.getElementById("tableDisplay");
       //Option 1: Change the style attribute directly
   		x.style.display="none";
  
	}

function openTable(){
      // Find the element
   		x=document.getElementById("tableDisplay");
      //Option 1: Change the style attribute directly
   		 x.style.display="block";
 
	}
function closeMe2(){
      // Find the element
   		x=document.getElementById("formDisplay2");
       //Option 1: Change the style attribute directly
   		x.style.display="none";
  
	}

function openMe2(){
      // Find the element
   		x=document.getElementById("formDisplay2");
      //Option 1: Change the style attribute directly
   		 x.style.display="block";
 
	}	